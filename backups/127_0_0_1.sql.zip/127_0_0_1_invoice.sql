-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2021 at 09:54 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `invoice`
--
CREATE DATABASE IF NOT EXISTS `invoice` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `invoice`;

-- --------------------------------------------------------

--
-- Table structure for table `lineitems`
--

CREATE TABLE `lineitems` (
  `recid` bigint(20) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `quantity` int(20) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `totalwithtx` decimal(10,2) DEFAULT NULL,
  `endeffdt` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lineitems`
--

INSERT INTO `lineitems` (`recid`, `name`, `price`, `tax`, `quantity`, `total`, `totalwithtx`, `endeffdt`) VALUES
(1, 'Apples', '100.00', 1, 5, '505.00', NULL, '2021-07-28'),
(2, 'Apples', '100.00', 1, 5, '505.00', NULL, '2021-07-28'),
(3, 'Apples', '100.00', 1, 5, '505.00', NULL, '2021-07-28'),
(4, 'Apples', '100.00', 1, 5, '505.00', NULL, '2021-07-28'),
(5, 'Apples', '10.00', 5, 3, '32.00', NULL, '2021-07-28'),
(6, 'Apples', '10.00', 1, 5, '50.00', '50.50', '2021-07-28'),
(7, 'Apples', '100.00', 10, 2, '200.00', '220.00', '2021-07-28'),
(8, 'Apples', '5.00', 1, 5, '25.00', '25.25', '2021-07-28'),
(9, 'peaches', '2.00', 10, 1, '2.00', '2.20', NULL),
(10, 'Oranges', '10.00', 1, 200, '2000.00', '2020.00', '2021-07-29'),
(11, 'Apples', '5.00', 0, 6, '30.00', '30.00', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lineitems`
--
ALTER TABLE `lineitems`
  ADD PRIMARY KEY (`recid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lineitems`
--
ALTER TABLE `lineitems`
  MODIFY `recid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
